class AppConstants {
  static const String cloudinaryCloudName =
      'djnqejhoj'; // Replace with your Cloudinary Cloud Name
  static const String cloudinaryUploadPreset =
      'COMSICON'; // Replace with your Upload Preset Name
  static const String cloudinaryFolder =
      'COMSICON/'; // Replace with your folder structure
}
